package com.expoMoney.tenancy.multitenancy;

import org.hibernate.context.spi.CurrentTenantIdentifierResolver;
import org.springframework.stereotype.Component;

@Component
public class CurrentTenantIdentifierResolverImpl implements CurrentTenantIdentifierResolver {

    @Override
    public String resolveCurrentTenantIdentifier() {
        String tenantId = TenantContext.getCurrentTenant();
        System.out.println("Resolvendo Tenant : " + tenantId);
        System.out.println("Resolvendo Tenant no Hibernate: " + tenantId);
        return tenantId != null ? tenantId : "public"; // Retorna 'public' como padrão
    }

    @Override
    public boolean validateExistingCurrentSessions() {
        return true;
    }
}